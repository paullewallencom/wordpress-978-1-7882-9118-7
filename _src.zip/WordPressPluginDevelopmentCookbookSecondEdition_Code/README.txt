Chapter 1, Preparing a Local Development Environment, walks you through all of the tools
that are useful to have when developing so it has no code files.

Plugins for WordPress, including a local web
server, a Subversion client, and a dedicated code editor. While this book will always
describe all of the steps necessary to perform its recipes, having a good understanding of
WordPress will allow you to fully appreciate the information contained in these pages.