<?php
/*
Plugin Name:	Chapter 2 - Plugin Header
Plugin URI:
Description:	Declares a plugin that will be visible in the WordPress admin interface
Version:		1.0
Author:			Yannick Lefebvre
Author URI:		http://ylefebvre.ca
License:		GPLv2
*/